import React from 'react'
import './home.css'
function home() {
  return (
    <>
      <html>
      <head>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"></meta>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"></link>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
      </head>
<body>
<div id="demo" class="carousel slide" data-ride="carousel">
<ol class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="https://images.unsplash.com/photo-1463694372132-6c267f6ba561?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1yZWxhdGVkfDF8fHxlbnwwfHx8fA%3D%3D&auto=format&fit=crop&w=500&q=60"  width="100%" height="600"></img>
      <div class="carousel-caption">
        <h1>WE PROVIDE BEST GUIDANCE</h1>
<h5>You’ll always have fascinating places to be and friendly people to see.
</h5>
      </div>
    </div>
    <div class="carousel-item ">
      <img src="https://images.unsplash.com/photo-1539635278303-d4002c07eae3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjN8fGFkdmVudHVyZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"  width="100%" height="600"></img>
    </div>
    <div class="carousel-item ">
      <img src="https://images.unsplash.com/photo-1539635278303-d4002c07eae3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjN8fGFkdmVudHVyZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"  width="100%" height="600"></img>
    </div>
  </div>
   <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<br></br><br></br>
<div class="container">
  
    <div class="row mt-3">
      <div class="col-12 col-sm-6">
  <img class="img1" src="https://images.unsplash.com/photo-1465188162913-8fb5709d6d57?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTE2fHxhZHZlbnR1cmV8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60" ></img>
  </div>
  <div class="col-12 col-sm-6 mt-5">
 <h1 class="spec" > We Are Specialised At-</h1>
 <p class="qqqq">
Switzerland Tour<br></br>
Beach Tour<br></br>
Thailand Tour<br></br>
Historical Tour<br></br>
Adventure Tour</p>
</div>
</div>
<br></br><br></br>
<div>
<video controls muted autoPlay>
  <source src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSgZSAn6MXtGJPNYAIp4amGV0LSRvFIcd1Jnw&usqp=CAU" ></source>
</video>

</div>
<img class="www mt-3" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2qhhXaAKzjpf8KVROaezV0rL__CC8H1DO3A&usqp=CAU" width="40px;" height="40px"></img>
<p class="wwww mt-3" >What we do?</p>
<img class="www mt-2" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2qhhXaAKzjpf8KVROaezV0rL__CC8H1DO3A&usqp=CAU" width="40px" height="40px"></img>
<p class="wwww mt-3">Why choose us?</p>
<img class="www mt-2" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2qhhXaAKzjpf8KVROaezV0rL__CC8H1DO3A&usqp=CAU" width="40px;" height="40px"></img>
<p class="wwww mt-3">How we work?</p>
<br></br><br></br>
</div>
<div class="logos">
  <img class="img-thumbnail1 mt-1 rounded-circle " src="https://i.pngimg.me/thumb/f/720/5d6d1503582641f4b2e6.jpg" width="180px;" height="180px;" ></img>
   <img class="img-thumbnail2 mt-1 rounded-circle  " src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTXS_sGIAE8ak7onnze1VurrNCOQtFkKQdqMhETHcPrcQpeDUVVS9ogX0LlfyzVBxZcTc4&usqp=CAU" width="180px;" height="180px;"></img>
   <img class="img-thumbnail3 mt-1 rounded-circle " src="https://image.similarpng.com/very-thumbnail/2020/08/Adventure-logo-design-on-transparent-background-PNG.png" width="180px;" height="180px;"></img>
<img class="img-thumbnail4 mt-1 rounded-circle " src="https://comps.gograph.com/world-tour-travel_gg87076414.jpg" width="180px;" height="180px;"></img>
</div>
<br></br><br></br>

<div class="end mt-5">
  <p class="aaa ">We Are With You At Every<br></br>
Stage Of Your Journey</p>
<p class="aaaa">Fugit tempora dolor dolore recusandae aut at cum autem esse neque. <br>
</br>Consequuntur dolor sequi nulla corrupti blanditiis similique</p>
<button type='submit' class="btn btn-primary">Book Your Travel</button>
</div>
</body>
</html>

</>
  )
}

export default home
