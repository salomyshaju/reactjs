const Data2 = {
    productData:[
        {
        id:16,
        img:'https://static-ssl.businessinsider.com/image/5a7dc169d03072af008b4bf2-807/red%20robin%20.jp2',
        title:'Burger',
        desc:'fried chicken',
        price:150,
        },
        {
            id:17,
            img:'https://media.istockphoto.com/id/1296474411/photo/piece-of-sachertorte-sachr-cake-on-white-plate-top-view-copy-space.jpg?b=1&s=170667a&w=0&k=20&c=4FL6ZEbWY-eqJDY8-pa5aeXKCuae6vT1D6_d1E5xMFI=',
            title:'Cake',
            desc:'dark chocolate',
            price:150,
            },
            {
                id:18,
                img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRmMgUD5twFI638s7BV9KkCv3BdLGCtuDhhKQ&usqp=CAU',
                title:'Cake',
                desc:'red velvet',
                price:150,
                },
                {
                    id:19,
                    img:'https://www.asweetpeachef.com/wp-content/uploads/2021/09/frozen-desserts-for-weight-loss-1.jpg',
                    title:'Ice cream',
                    desc:'strawberry',
                    price:150,
                    },
                    {
                        id:20,
                        img:'https://www.allrecipes.com/thmb/BY8CcWT0JZOjFcWeIem9Fik1x78=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/9266919-c023924050f9406bab6eccea1664e88b.jpg',
                        title:'cake',
                        desc:'chocolate',
                        price:150,
                        },
                        {
                            id:21,
                            img:'https://www.funfoodfrolic.com/wp-content/uploads/2021/05/Mango-Shake-Thumbnail.jpg',
                            title:'Shake',
                            desc:'mango',
                            price:150,
                            },
                            {
                                id:22,
                                img:'https://img.freepik.com/free-photo/side-view-chicken-doner-with-greens-cucumber-tomato-sauce-cucumber-red-onion-pita-slice-lemon-board_141793-4824.jpg?w=2000',
                                title:'Shawarma',
                                desc:'cheese',
                                price:150,
                                },
                                {
                                    id:23,
                                    img:'https://prettysweetblog.com/wp-content/uploads/2021/01/No-bake-chocolate-hazelnut-dessert-in-a-glass-1-2.jpg',
                                    title:'Cake',
                                    desc:'dark & white choco',
                                    price:150,
                                    },
                                    {
                                        id:24,
                                        img:'https://www.whiskaffair.com/wp-content/uploads/2020/07/Oreo-Milkshake-2-3.jpg',
                                        title:'Shake',
                                        desc:'choco',
                                        price:150,
                                        },
                                        {
                                            id:25,
                                            img:'https://www.licious.in/blog/wp-content/uploads/2022/02/shutterstock_1339636625-600x600.jpg',
                                            title:'Shawarma',
                                            desc:'chicken',
                                            price:150,
                                            },

                
    ],
    
};
export default Data2;