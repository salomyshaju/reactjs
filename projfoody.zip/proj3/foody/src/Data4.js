const Data4 = {
    productData:[
        {
        id:31,
        img:'https://www.hangoutfoodie.com/wp-content/uploads/2022/02/ab2c4c99-travelling_foodiee_83331348_476898942985417_289148691712777709_n-600x600.jpg',
        title:'veg-meal',
        desc:'',
        price:150,
        },
        {
            id:32,
            img:'https://thumbs.dreamstime.com/b/indian-non-vegetarian-meal-south-thali-meat-cury-rice-raita-dal-paneer-chicken-curry-61243061.jpg',
            title:'Non-veg',
            desc:'',
            price:150,
            },
            {
                id:33,
                img:'https://www.portablepress.com/wp-content/uploads/2017/10/Fast-food-combo-meal.jpg',
                title:'Burger(v)',
                desc:'',
                price:150,
                },
                {
                    id:34,
                    img:'https://d1sag4ddilekf6.azureedge.net/compressed_webp/items/SGITE2021091506555964133/detail/menueditor_item_8597e958c5ad4bdb9ce8e23447edc666_1631689716392222677.webp',
                    title:'Tandoori',
                    desc:'',
                    price:150,
                    },
                    {
                        id:35,
                        img:'https://www.shutterstock.com/image-photo/manchurian-hakka-schezwan-noodles-popular-260nw-1377427199.jpg',
                        title:'Noodles-N',
                        desc:'',
                        price:150,
                        },
                
    ],
    
};
export default Data4;