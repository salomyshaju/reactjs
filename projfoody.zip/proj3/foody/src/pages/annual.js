import React from 'react';

const AnnualReport = () => {
return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>Annual Report</h1>
	</div>
);
};

export default AnnualReport;
