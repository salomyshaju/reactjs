import React from 'react'
import './about.css'
function about() {
  return (
	<>
	<html>
      <head>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"></link>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
      </head>
      <div class="rtyu">
     <div class="ooo">
<div class="four">
    <img class="two" src="https://images.unsplash.com/photo-1502791451862-7bd8c1df43a7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=464&q=80"></img>
    <h3 class="hhh">why choose us?</h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sapien diam, ornare a eros a, mollis facilisis erat. Sed gravida turpis lorem, id gravida erat dictum et.Lorem ipsum dolor sit amet, consectetur adipiscing elit Sed sapien diam, ornare a eros a, mollis facilisis erat.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed sapien diam, ornare a eros a, mollis facilisis erat. Sed gravida turpis lorem, id gravida erat dictum et.Lorem ipsum dolor sit amet, consectetur adipiscing elit Sed sapien diam, ornare a eros a, mollis facilisis erat.</p>
    <div class="row">
      <div class="co1-12 col-sm-6">
      <ul>
      <li>Explore Things</li>
      <li>Museum Tickets</li>
      <li>Sightseeing</li>
      <li>Outdoor Trips</li>
    </ul>
      </div>
      <div class="co1-12 col-sm-6">
      <li>Transportation</li><li>Attraction Clubs</li>
      <li>Attraction Tickets</li><li>Expensive less</li>
    </div>
    </div>
    </div>
    <br></br>
    <h1 class="lll">Why We Are The Best</h1>
    <p>Ut enim ad minima veniam, quis nostrum exercitationem ulla corporis suscipit laboriosam, 
      nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum exercitationem ulla corporis 
      suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum exercitationem 
      ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum 
      exercitationem ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, 
      quis nostrum exercitationem ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.</p>
    </div>


<div class="slide-container">
  <h1 class="aabb bg-dark">What People Say</h1>
  <div class="slide-content">
    <div class="card-wrapper">
      <div class="card">
        <div class="image-content">
          <span class="overlay"></span>
          <div class="card-image">
            <img src="https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8OTh8fHBlcnNvbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="card-img"></img>
          </div>
        </div>
        <div class="card-content">
          <h2 class="name">David</h2>
          <p class="description">m ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud  </p>
<button  class="button">view more</button>
        </div>
      </div>

      <div class="card">
        <div class="image-content">
          <span class="overlay"></span>
          <div class="card-image">
            <img src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjR8fHBlcnNvbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="card-img"></img>
          </div>
        </div>
        <div class="card-content">
          <h2 class="name">Irin</h2>
          <p class="description">m ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
<button  class="button">view more</button>
        </div>
      </div>

      <div class="card">
        <div class="image-content">
          <span class="overlay"></span>
          <div class="card-image">
            <img src="https://images.unsplash.com/photo-1557862921-37829c790f19?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTd8fHBlcnNvbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="card-img"></img>
          </div>
        </div>
        <div class="card-content">
          <h2 class="name">Alex</h2>
          <p class="description">m ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud </p>
<button  class="button">view more</button>
        </div>
      </div>
    </div>
  </div>
</div>
</div>
	</html>
	</>
);
};

export default about;
