import React from 'react'
import './gallery.css'
function gallery() {
  return (
    <>
   
   <div class="container" >
    <h2 class="hh2">Our Gallery</h2>
    <br></br>
    
      <div class="section ">
        <img class="gall" src="https://images.unsplash.com/photo-1499002238440-d264edd596ec?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8ODF8fG5hdHVyZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"></img>
        <img class="gall" src="https://images.unsplash.com/photo-1569949380643-6e746ecaa3bd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTd8fHRvdXJ8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"></img></div>
<div class="section">
        <img class="gall1" src="https://images.unsplash.com/photo-1458501534264-7d326fa0ca04?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTE2fHxuYXR1cmV8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60" height="377px"></img>
        <img class="gall1" src="https://images.unsplash.com/photo-1504567961542-e24d9439a724?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NjB8fG5hdHVyZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"></img>
  </div>
<div class="section">
<img class="gall3" src="https://images.unsplash.com/photo-1598890777032-bde835ba27c2?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTh8fHRvdXJ8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60"   ></img> 
<img class="gall3" src="https://images.unsplash.com/photo-1502082553048-f009c37129b9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mjl8fG5hdHVyZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"></img>
</div>
<div class="section">
<img class="gall2" src="https://images.unsplash.com/photo-1431794062232-2a99a5431c6c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MzN8fG5hdHVyZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" height="390px"   ></img>   
<img class="gall2" src="https://images.unsplash.com/photo-1484766280341-87861644c80d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NDV8fG5hdHVyZXxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60"  ></img>
</div>
</div>
   
    </>
  )
}

export default gallery


