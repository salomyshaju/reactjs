import React from 'react';
import Home from './home';
import About from './about';
import Services from './services';
import Ending from './Ending';
import Team from './team';
const Open = () => {
return (
	<div>
	<Home/>
	<About/>
	<Services/>
	<Team/>
	<Ending/>
	</div>
);
};
export default Open;

