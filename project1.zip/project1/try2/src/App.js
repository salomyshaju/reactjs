import NavBar from './Components/NavBar';
import React from 'react';
import{ BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import Open from './pages';
import Home from './pages/home';
import About from './pages/about';
import Services from './pages/services';
import Gallery from './pages/gallery';
import Teams from './pages/team';
import SignUp from './pages/signup';
import signin from './pages/signin';



function App() {
  return (
  <Router>
  <NavBar/>
  <Switch>
        <Route path='/' exact component={Open} />
        <Route path='/home' component={Home}/>
        <Route path='/about' component={About} />
        <Route path='/services' component={Services} />
        <Route path='/gallery' component={Gallery} />
        <Route path='/team' component={Teams} />
        <Route path='/sign-up' component={SignUp} />
        <Route path='/signin' component={signin} />
      </Switch>
  </Router>
  );
}

export default App;
