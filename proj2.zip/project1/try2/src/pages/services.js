import React from 'react';
import './services.css'

const Events = () => {
return (
	<>
	<html>
      <head>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"></link>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
      </head>
	  <body>
	  <div class="container" style={{
      marginTop:'30px',
    }}>
	<div class="card-deck">
    <div class="xxx card bg-dark rgb">
      <div class="card-body text-center">
		<img class="cardimg" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSwl3U_9XW8dFt7qXsxZ_3xRiO1Ufxyx_wDPg&usqp=CAU" width="200px" height="126px"></img>
    <h1 class="xxxx">Hotel</h1>
        <p class="card-text">Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.</p>
      </div>
    </div>
    <div class="xxx card bg-dark rgb">
      <div class="card-body text-center">
		<img class="cardimg" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSaPYIBNws0W2s4WrnbxzxuX1voUFsoJ5sdQg&usqp=CAU" width="200px" height="126px"></img>
    <h1 >Pick Up</h1>
        <p class="card-text">Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.</p>
      </div>
    </div>
    <div class="xxx card bg-dark rgb">
      <div class="card-body text-center">
		<img class="cardimg" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR4BtJmDEe1p4L78QAiyV28dMc1WpHQWtH8Ag&usqp=CAU" width="200px" height="126px"></img>
    <h1 >Restaurent</h1>
        <p class="card-text">Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.</p>
      </div>
    </div>
    <div class="xxx card bg-dark rgb">
      <div class="card-body text-center">
		<img class="cardimg" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTc5GNlQLt6ri4UIPtmTOlicZbA_LDiTo6dw&usqp=CAU" width="200px" height="126px"></img>
    <h1 c>Photography</h1>
        <p class="card-text">Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.</p>
      </div>
    </div>  
  </div>
  </div>
<br></br><br></br>
<div class="pac row mt-3">
      <div class="col-12 col-sm-6">
  <img class="img11" src="https://plus.unsplash.com/premium_photo-1663051152686-4b13c03d81f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTkxfHxmYW1pbHl8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60" width="625px"></img>
  </div>
  <div class="col-12 col-sm-6 mt-5">
 <h1 class="wqe" >Family Packages</h1>
 <p class="qqqqq">Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.
 Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.
</p>
</div>
</div>
<div class="pac row ">
       <div class="col-12 col-sm-6 mt-5">
 <h1 class="wqe" >Group Travel</h1>
 <p class="qqqqq">Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.
 Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.
</p>
</div>
<div class="col-12 col-sm-6">
  <img class="img11" src="https://images.unsplash.com/photo-1591035897819-f4bdf739f446?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTJ8fGZyaWVuZHN8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60" width="625px"></img>
  </div>
</div>
<div class="pac row ">
      <div class="col-12 col-sm-6">
  <img class="img11" src="https://images.unsplash.com/photo-1633431305692-00a2f1a5c3d5?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjF8fGNvdXBsZSUyMGltYWdlc3xlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" width="625px" ></img>
  </div>
  <div class="col-12 col-sm-6 mt-5">
 <h1 class="wqe" >HoneyMoon Packages</h1>
 <p class="qqqqq">Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.
 Suspendisse bibendum ex sit amet tellus finibus ultrices.Suspendisse bibendum ex sit amet tellus finibus ultrices.
</p>
</div>
</div>
<br></br><br></br>
  </body>
</html>
	</>
	
);
};

export default Events;
