import React from 'react';
import {
Nav,
NavLink,
Bars,
NavMenu,
} from './NavbarElements';

const Navbar = () => {
return (
	<>
	<Nav style={{
		position:'sticky',
		top:'0',
		left:'0',
		display:'flex',
		transition:'padding 1s',
		width:'100%',
	}}>
		<Bars />
        <NavLink  to="/" class="navbar-brand" style={{color:'blue',
	fontSize:'45px',
	marginLeft:'80px',
	fontFamily:'robosto',
	fontWeight:'900',
textDecoration:'none',}
	}>Travel Mate</NavLink>
		<NavMenu >
		<NavLink to='/home' activeStyle>
			Home
		</NavLink>
		<NavLink to='/about' activeStyle>
			About
		</NavLink>
		<NavLink to='/services' activeStyle>
			Services
		</NavLink>
		<NavLink to='/gallery' activeStyle>
			Gallery
		</NavLink>
		<NavLink to='/team' activeStyle>
			Teams
		</NavLink>
		<NavLink to='/signup' activeStyle>
			Sign Up
		</NavLink>
		{/* Second Nav */}
		{/* <NavBtnLink to='/sign-in'>Sign In</NavBtnLink> */}
		</NavMenu>
	</Nav>
	</>
);
};

export default Navbar;
