const Data1 = {
    productData:[
        {
        id:11,
        img:'https://static.theprint.in/wp-content/uploads/2020/11/pizza.jpg?compress=true&quality=80&w=376&dpr=2.6',
        title:'Pizza',
        desc:'chicken',
        price:150,
        },
        {
            id:12,
            img:'https://cdn0.weddingwire.in/article-vendor-o/1701/3_2/960/jpg/spare-2-can-use-for-anything_15_71701.jpeg',
            title:'Barbeque',
            desc:'chicken',
            price:150,
            },
            {
                id:13,
                img:'https://post.medicalnewstoday.com/wp-content/uploads/sites/3/2020/02/321331_2200-1200x628.jpg',
                title:'Paneer',
                desc:'fried',
                price:150,
                },
                {
                    id:14,
                    img:'https://www.whiskaffair.com/wp-content/uploads/2022/03/Bihari-Chicken-Curry-2-3.jpg',
                    title:'Chicken',
                    desc:'curry',
                    price:150,
                    },
                    {
                        id:15,
                        img:'https://media.istockphoto.com/id/481754150/photo/chicken-on-a-hot-flaming-barbecue.jpg?s=612x612&w=0&k=20&c=QWA3qlprrjiKzlclNHIzIqMTmKYoY9ZJlFRCieZEvhw=',
                        title:'Barbeque',
                        desc:'chicken',
                        price:150,
                        },
                        

                
    ],
    
};
export default Data1;