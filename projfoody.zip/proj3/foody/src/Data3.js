const Data3= {
    productData:[
        {
        id:26,
        img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT2EDlqg3Lt8Om_Dw5503w9zC40ctROUyHmrg&usqp=CAU',
        title:'Kunafa',
        desc:'10% off',
        price:150,
        },
        {
            id:27,
            img:'https://thumbs.dreamstime.com/b/fish-fry-993103.jpg',
            title:'Fish',
            desc:'5% off',
            price:150,
            },
            {
                id:28,
                img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQGCRcmbIvMLsA5JTXYtnKfN1LOfA18dFkyw&usqp=CAU',
                title:'Sandwitch',
                desc:'20% off',
                price:150,
                },
                {
                    id:29,
                    img:'https://b.zmtcdn.com/data/reviews_photos/e59/52949dc958f00c41c1de1c903b519e59_1576249873.jpg?fit=around|750:500&crop=750:500;*,*',
                    title:'Rice',
                    desc:'30% off',
                    price:150,
                    },
                    {
                        id:30,
                        img:'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1QpGFFUc2QL7vjVe3-To2fYceSUTRiE_-Fw&usqp=CAU',
                        title:'Rice',
                        desc:'26% off',
                        price:150,
                        },
        
                
    ],
    
};
export default Data3;