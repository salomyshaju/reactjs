
const Data = {
    productData:[
        {
            id:1,
            name:'Alwin',
            email:'sdfghj@gmail.com',
            accountnum:'987654',
            img:'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NzB8fHByb2ZpbGV8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
            phone:"678909805",
            address:"rtyujgujhi p.o",
            amount:"10000"

        },
        {
            id:2,
            name:'Anu',
            email:'anu123@gmail.com',
            accountnum:'98076',
            amount:10000,
            img:'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTh8fHByb2ZpbGV8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
            phone:"235467890",
            address:"fhkghkjjl p.o",
            
            },
            {
                id:3,
                name:'jack',
                email:'jack123@gmail.com',
                accountnum:'578990',
                amount:23000,
                img:'https://images.unsplash.com/photo-1603415526960-f7e0328c63b1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTN8fHByb2ZpbGV8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
                phone:"675789080",
                address:"gjhkjlk p.o",
                },
                {
                    id:4,
                    name:'claire',
                    email:'claire123@gmail.com',
                    accountnum:'08975',
                    amount:89000,
                    img:'https://images.unsplash.com/photo-1544725176-7c40e5a71c5e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8ODR8fHByb2ZpbGV8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
                    phone:"12354546",
                    address:"mnjklou p.o",
                   
                    },
                    {
                        id:5,
                        name:'jhone',
                        email:'jhone123@gmail.com',
                        accountnum:'567678',
                        amount:2300,
                        img:'https://images.unsplash.com/photo-1556157382-97eda2d62296?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NTh8fHByb2ZpbGV8ZW58MHx8MHx8&auto=format&fit=crop&w=500&q=60',
                        phone:"679089089",
                        address:"fhbghkj p.o",
                        
                        },
                        {
                            id:6,
                            name:'jack',
                            email:'jack123@gmail.com',
                            accountnum:'445456',
                            amount:45000,
                            img:'https://images.unsplash.com/photo-1590031905406-f18a426d772d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTY3fHxwcm9maWxlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
                            phone:"269009754",
                            address:"fchgj p.o",
                            },
                            {
                                id:7,
                                name:'Alex',
                                email:'alex123@gmail.com',
                                accountnum:'76889',
                                amount:7000,
                                img:'https://images.unsplash.com/photo-1463453091185-61582044d556?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTM4fHxwcm9maWxlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
                                phone:"548708895",
                                address:"fhhjk p.o",
                                },
                                {
                                    id:8,
                                    name:'Mary',
                                    email:'mary1233@gmail.com',
                                    accountnum:'43756',
                                    amount:2000,
                                    img:'https://images.unsplash.com/photo-1595085610896-fb31cfd5d4b7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTE2fHxwcm9maWxlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
                                    phone:"4564564567",
                                    address:"hjmkjh p.o",
                                    },
                                    {
                                        id:9,
                                        name:'Gouri',
                                        email:'gouri123@gmail.com',
                                        accountnum:'546880',
                                        amount:19000,
                                        img:'https://images.unsplash.com/photo-1470441623172-c47235e287ee?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTQ2fHxwcm9maWxlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
                                        phone:"7899067865",
                                        address:"hfngh p.o",
                                        },

                                     {
                                            id:10,
                                            name:'Liya',
                                            email:'liya123@gmail.com',
                                            accountnum:'56789890',
                                            amount:68000,
                                            img:'https://images.unsplash.com/photo-1595085610978-b5e35eb24dcf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTcwfHxwcm9maWxlfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60',
                                            phone:"342323489",
                                            address:"qwertfd p.o",
                                            },

                
    ],
    
};
export default Data;