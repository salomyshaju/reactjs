const Data5 = {
    productData:[
        {
        id:36,
        img:'https://thumbs.dreamstime.com/b/kunafa-traditional-turkish-dessert-kunefe-kunafa-kadayif-pistachio-powder-cheese-hot-eaten-sweet-gaziantep-s-famous-168560044.jpg',
        title:'Kunafa',
        desc:'white chocolate',
        price:150,
        },
        {
            id:37,
            img:'https://b.zmtcdn.com/data/pictures/7/18611657/2eca5ab6fd8451d28181d0c6bfb94535_featured_v2.jpg',
            title:'pizza',
            desc:'chicken',
            price:150,
            },
            {
                id:38,
                img:'https://cdn.pixabay.com/photo/2016/03/05/19/02/hamburger-1238246__480.jpg',
                title:'Burger',
                desc:'chicken',
                price:150,
                },
                {
                    id:39,
                    img:'https://images.unsplash.com/photo-1585032226651-759b368d7246?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NXx8bm9vZGxlc3xlbnwwfHwwfHw%3D&w=1000&q=80',
                    title:'Noodles',
                    desc:'veg',
                    price:150,
                    },
                    {
                        id:40,
                        img:'https://1.bp.blogspot.com/-mIFYDwUkzcE/X2ELrRXkmvI/AAAAAAAAYu4/SpC-hHSD1dwG6wXdXjq9wq5cO7eS2F6eACLcBGAsYHQ/s2048/kunafa%2B10.JPG',
                        title:'Kunafa',
                        desc:'dark & white chocolate',
                        price:150,
                        },
                        {
                            id:41,
                            img:'https://www.foodnetwork.com/content/dam/images/food/fullset/2009/4/8/0/Cream-Cheese-Brownies_s4x3.jpg',
                            title:'Browni',
                            desc:'white $ chocolate',
                            price:150,
                            },
                            {
                                id:42,
                                img:'https://iambaker.net/wp-content/uploads/2014/06/861A6402.brwonie.jpg',
                                title:'browni',
                                desc:'dark chocalote',
                                price:150,
                                },
                                {
                                    id:43,
                                    img:'https://static.toiimg.com/thumb/47704347/Alleppeys-best-seafood-joints.jpg?width=1200&height=900',
                                    title:'Fish',
                                    desc:'prawn',
                                    price:150,
                                    },
                                    {
                                        id:44,
                                        img:'https://cdn.shopify.com/s/files/1/0521/3929/4884/products/RedVelvetCake1_400x400.jpg?v=1632143747',
                                        title:'Cake',
                                        desc:'red velvet',
                                        price:150,
                                        },
                                        {
                                            id:45,
                                            img:'https://www.thegraciouswife.com/wp-content/uploads/2018/11/White-Chocolate-Peppermint-Brownies-Recipe-feature.jpg',
                                            title:'Browni',
                                            desc:'white chocalate',
                                            price:150,
                                            },
                                            
                    

                
    ],
    
};
export default Data5;