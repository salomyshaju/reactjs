import React from 'react'
import './ending.css';
import {FaAddressBook, FaFacebook, FaInstagram, FaLandmark, FaMap, FaMobile, FaPhone, FaTwitter } from 'react-icons/fa';
function ending() {
  return (
    <>
  
      <div class="mnb">
        <div class="row">
          <div class="col-12 col-md-6">
      <ul class="ull">
        <li class="liii "><a class="lii" href="/home">Home</a></li>
        <li class="liii"><a class="lii" href="/about">About</a></li>
        <li  class="liii"><a class="lii" href="/services">Services</a></li>
        <li class="liii" ><a class="lii" href="/gallery">Gallery</a></li>
        <li class="liii"><a class="lii" href="/team">Team</a></li>
        <li class="liii" ><a class="lii" href="/signup">Signup</a></li>
      </ul>
      </div>
      <div class="as col-12 col-md-6">
          <a class="faicons" href="https://www.facebook.com">
     <FaFacebook/></a>
     <a class="faicons" href="https://www.instagram.com">
     <FaInstagram/></a>
     <a class="faicons" href="https://www.twitter.com">
     <FaTwitter/></a>
      </div>
      </div>
      <div class="row1">
        <div class="we col-12 col-sm-6 col-md-4">
          <FaAddressBook/><p class="rr">ADDRESS</p><p class="rr">123 USA</p>
        </div>
        <div class="we col-12 col-sm-6 col-md-4 ">
          <FaMobile/><p class="rr">PHONE</p><p class="rr">1346890975</p>
        </div>
        <div class="we col-12 col-sm-6 col-md-4 ">
          <FaPhone/><p class="rr">PHONE</p><p class="rr">+24789035</p>
        </div>
      </div>
      </div>
      </>
  )
}

export default ending
