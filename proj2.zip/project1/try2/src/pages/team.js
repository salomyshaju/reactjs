import React from 'react'
import './team.css';
function team() {
  return (
	<>
	<head>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"></link>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
	</head>
	<h1 class="olm">Our Team</h1>
	  <div class="container">
		<div class="media">
			<img  src="https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MjR8fHBlcnNvbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="qaz rounded-circle"></img>
			<div class="media-body">
				<h4 class="mdb">Jane</h4>
				<p class="p1">Ut enim ad minima veniam, quis nostrum exercitationem ulla corporis suscipit laboriosam, 
      nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum exercitationem ulla corporis 
      suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum exercitationem 
      ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum 
      exercitationem ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, 
      quis nostrum exercitationem ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.</p>
	  <div class="media">
			<img  src="https://images.unsplash.com/photo-1544723795-3fb6469f5b39?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NDR8fHBlcnNvbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="qaz rounded-circle"></img>
			<div class="media-body">
				<h4 class="mdb">Jhone</h4>
				<p class="p1">Ut enim ad minima veniam, quis nostrum exercitationem ulla corporis suscipit laboriosam, 
      nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum exercitationem ulla corporis 
      suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum exercitationem 
      ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum 
      exercitationem ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, 
      quis nostrum exercitationem ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.</p>
	  <div class="media">
			<img  src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NDB8fHBlcnNvbnxlbnwwfHwwfHw%3D&auto=format&fit=crop&w=500&q=60" class="qaz rounded-circle"></img>
			<div class="media-body">
				<h4 class="mdb">Claire</h4>
				<p class="p1">Ut enim ad minima veniam, quis nostrum exercitationem ulla corporis suscipit laboriosam, 
      nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum exercitationem ulla corporis 
      suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum exercitationem 
      ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, quis nostrum 
      exercitationem ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.Ut enim ad minima veniam, 
      quis nostrum exercitationem ulla corporis suscipit laboriosam, nisi ut aliquid ex ea.</p>
	  </div>
	  </div>
		</div>
		</div>
	  </div>
	  </div>
	  </div>
	
	</>
  )
}

export default team


	

