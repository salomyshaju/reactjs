import React from 'react';
import home from './home';
const Open = () => {
return (
	<div
	style={{
		display: 'flex',
		justifyContent: 'center',
		alignItems: 'Right',
		height: '100vh'
	}}
	>
	<h1>Welcome</h1>
	</div>
);
};
export default Open;

