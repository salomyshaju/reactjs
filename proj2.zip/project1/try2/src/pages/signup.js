import React, { useState } from "react";
import axios from "axios";
import FormData from "form-data";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function SignUp() {
  const url = "http://192.168.1.43/api/user-registration";
  const [data, setData] = useState({
    name: "",
    email: "",
    phone: "",
    password: "",
  });


  // const notify = () => {
  //   toast.success("The User registered Successfully");
  // }

  const handle = (e) => {
    const newData = { ...data };
    newData[e.target.id] = e.target.value;
    setData(newData); 
  };

  


  const handleSubmit = (e) => {
    console.log(JSON.stringify(data))
    e.preventDefault();
   
    var form = new FormData();
form.append('name', data.name);
form.append('email', data.email);
form.append('phone', data.phone);
form.append('password', data.password);

    axios
    .post(url, form ,{
        // method: "post",
        // url: url,
        // data: form,
        headers: { "Content-Type": "multipart/form-data" },
      })
    .then((response) => {
      // console.log(response);
      // console.log(response.data);
      setData({ ...data, id: e.target.value})
      toast.success("The User registered Successfully");
    });
    // .catch((error) => {
    //   if (error.response) {
    //     console.log(error.response);
    //     console.log("server responded");
    //   } else if (error.request) {
    //     console.log("network error");
    //   } else {
    //     console.log(error);
    //   }
    // });
   
  }; 


  return (
    <>
    <html>
      <head>
      <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"></link>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
      </head>
   
       <center>   
       <div class="mmm" style={{
        backgroundPosition:'centre',
        backgroundSize:'cover',
        backgroundRepeat:'no-repeat',
        width:'100%',
        height:'100%',
        backgroundImage:'url(https://images.unsplash.com/photo-1579548122080-c35fd6820ecb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxzZWFyY2h8MTB8fGJsdWUlMjBiYWNrZ3JvdW5kfGVufDB8fDB8fA%3D%3D&auto=format&fit=crop&w=500&q=60)',
      }}>
    <div class="form" >
   <div class="title">Welcome</div>
   <div class="subtitle">Login Here!</div>
   <div class="input-container ic1">
     <input id="firstname" class="input" type="text" placeholder=" " />
     <div class="cut"></div>
     <label for="firstname" class="placeholder">First name</label>
   </div>
   <div class="input-container ic2">
     <input id="lastname" class="input" type="text" placeholder=" " />
     <div class="cut"></div>
     <label for="lastname" class="placeholder">Last name</label>
   </div>
   <div class="input-container ic2">
     <input id="email" class="input" type="text" placeholder=" " />
     <div class="cut cut-short"></div>
     <label for="email" class="placeholder">Email</label>
   </div>
   <button type="text" class="submit">LOGIN</button>
 </div>
 </div>
</center>
 </html>
 </>
  );
}

export default SignUp;