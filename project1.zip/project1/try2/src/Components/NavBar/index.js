import React from 'react';
import {
Nav,
NavLink,
Bars,
NavMenu,
H1,
} from './NavbarElements';

const Navbar = () => {
return (
	<>
	<Nav>
		<Bars />
        <H1 class="navbar-brand">Travel Mate</H1>
		<NavMenu>
		<NavLink to='/home' activeStyle>
			Home
		</NavLink>
		<NavLink to='/about' activeStyle>
			About
		</NavLink>
		<NavLink to='/services' activeStyle>
			Services
		</NavLink>
		<NavLink to='/gallery' activeStyle>
			Gallery
		</NavLink>
		<NavLink to='/team' activeStyle>
			Teams
		</NavLink>
		<NavLink to='/sign-up' activeStyle>
			Sign Up
		</NavLink>
		{/* Second Nav */}
		{/* <NavBtnLink to='/sign-in'>Sign In</NavBtnLink> */}
		</NavMenu>
		
	</Nav>
	</>
);
};

export default Navbar;
